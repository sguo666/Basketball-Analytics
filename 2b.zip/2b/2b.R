##2b
#import data
#transform the team info to numbers
#1-8 denotes East1 to East8; 9-17 denotes West1 to West8
#for equal seeds, just enter West1(9) as home while East1(1) as away
setwd("/Users/Sonya/Desktop")
busdata = read.csv("Business-Track.csv")
busdata = unlist(busdata)
busdata = as.numeric(busdata)
busdata = matrix(busdata, ncol = 16, byrow = TRUE)
busdata = t(busdata)
Revenue = busdata[1:16,2:5]

#install.packages("LaplacesDemon")
library(LaplacesDemon)

#Simulator for the Gate_Revenue for any round
simR = function(home,away,round){
  homeR = Revenue[home,round]
  awayR = Revenue[away,round]
  totalR = c(2 * homeR + 2 * awayR,
             3 * homeR + 2 * awayR,
             3 * homeR + 3 * awayR,
             4 * homeR + 3 * awayR)
  
  wexpR = sum(totalR * exawp(home,away))
  lexpR = sum(totalR * exalp(home,away))
  berp = sum(exawp(home,away))
  worl = rbern(1,berp)
  if (worl==1) {
    return(wexpR)
  }else{
    return(lexpR)
  }
}
#for example, East1(1) against East8(8) for first round
#simR(1,8,1)
#[1] 8823256
# for another example, East1(1) against West1(9) for the fourth round
#simR(9,1,4)
#[1] 32173774